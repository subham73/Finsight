from uuid import UUID
import uuid
from typing import List
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from models.exchange_rates import ExchangeRates
from routes.dashboard import get_user_projects
from schemas.projects import ProjectCreate, ProjectUpdate
from core.auth import get_current_user
from core.database import get_db
from models import projects as project_model, users as user_model, forecasts as forecast_model
from datetime import datetime
from sqlalchemy import or_, and_

router = APIRouter()

@router.get("/filters")
def get_filter_options(user=Depends(get_current_user), db: Session = Depends(get_db)):
    """Get all available filter options based on user role"""
    
    # Get projects using existing logic
    projects = get_user_projects(user, db)
    
    # Extract unique values
    regions = list(set(p.region for p in projects if p.region))
    statuses = list(set(p.status for p in projects if p.status))
    verticals = list(set(p.vertical for p in projects if p.vertical))
    customer_groups = list(set(p.customer_group for p in projects if p.customer_group))
    customer_names = list(set(p.customer_name for p in projects if p.customer_name))
 
    # Get available currencies from projects
    currencies = list(set(p.currency for p in projects if p.currency))
    
    # Get clusters - since you don't have clusters table, we'll get unique cluster_ids from projects
    cluster_ids = list(set(p.cluster_id for p in projects if p.cluster_id))
    clusters_data = []
    for cluster_id in cluster_ids:
        # Get cluster head name as cluster name
        cluster_head = db.query(user_model.User).filter(
            user_model.User.cluster_id == cluster_id,
            user_model.User.role == "CH"
        ).first()
        if cluster_head:
            clusters_data.append({
                "id": str(cluster_id),
                "name": f"{cluster_head.name}"
            })
    
    # Get managers based on user role
    if user.role == "SH":
        managers = db.query(user_model.User).filter(user_model.User.role == "PM").all()
        managers_data = [{"id": str(m.id), "name": m.name} for m in managers]
    elif user.role == "CH":
        # Get PMs in the same cluster
        managers = db.query(user_model.User).filter(
            and_(user_model.User.role == "PM", user_model.User.cluster_id == user.cluster_id)
        ).all()
        managers_data = [{"id": str(m.id), "name": m.name} for m in managers]
    else:  # PM
        managers_data = [{"id": str(user.id), "name": user.name}]
    
    # Get all available currencies from exchange rates table
    all_currencies = db.query(ExchangeRates.currency_code).all()
    available_currencies = [curr[0] for curr in all_currencies]
    
    return {
        "regions": sorted(regions),
        "statuses": sorted(statuses),
        "verticals": sorted(verticals),
        "currencies": sorted(currencies),  # Currencies from projects
        "available_currencies": sorted(available_currencies),  # All available currencies for conversion
        "clusters": clusters_data,
        "managers": managers_data,
        "customer_groups": customer_groups,
        "customer_names": customer_names
    }