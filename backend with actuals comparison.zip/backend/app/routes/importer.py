from fastapi import APIRouter, FastAPI, File, UploadFile, HTTPException, Depends
from fastapi.responses import JSONResponse
import re
import uuid
from logging import getLogger, ERROR, INFO
from decimal import Decimal
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Any
import pandas as pd
import numpy as np
from io import BytesIO
import tempfile
import os

from sqlalchemy.exc import SQLAlchemyError
from models import User, Cluster, Project, Forecast
from sqlalchemy.orm import Session

from core.database import get_db

# Setup logging
logger = getLogger("fastapi_actual_import")
logger.setLevel(INFO)

router = APIRouter()

class ActualExcelProcessor:
    def __init__(self, created_by_user_id: str):
        self.created_by_user_id = created_by_user_id
        self.column_mapping = {
            'project_number': ['IPMS ID'],
        }

    def parse_month_year(self, month_str: str) -> Tuple[int, int]:
        """
        Parse month-year from forecast column headers
        Examples: 'april'25', 'january'26'
        
        Returns:
            Tuple of (year, month)
        """
        try:
            month_map = {
                'january': 1, 'february': 2, 'march': 3, 'april': 4, 
                'may': 5, 'june': 6, 'july': 7, 'august': 8, 
                'september': 9, 'october': 10, 'november': 11, 'december': 12
            }
            
            month_nd_year = month_str.split('\'')
            
            if len(month_nd_year) >= 2:
                month_abbr = month_nd_year[0]
                year_suffix = month_nd_year[1]
                month = month_map.get(month_abbr.lower())
                
                if month:
                    year_suffix = int(year_suffix)
                    if year_suffix >= 0 and year_suffix <= 30:
                        year = 2000 + year_suffix
                    else:
                        year = 1900 + year_suffix
                    
                    return (year, month)
            
            logger.warning(f"Could not parse month/year from: {month_str}")
            return (2025, 1)
            
        except Exception as e:
            logger.error(f"Error parsing month/year from '{month_str}': {e}")
            return (2025, 1)

    def clean_forecast_value(self, value: Any) -> Decimal:
        """Clean and convert forecast values to Decimal"""
        if pd.isna(value) or value is None:
            return Decimal('0')
        
        if isinstance(value, str):
            value = value.strip()
            if value == '' or value == '-' or value.lower() == 'null':
                return Decimal('0')
        
        try:
            num_value = float(value)
            if num_value < 0:
                logger.warning(f"Negative forecast value found: {num_value}, setting to 0")
                return Decimal('0')
            return Decimal(str(num_value))
        except (ValueError, TypeError):
            logger.warning(f"Invalid forecast value: {value}, setting to 0")
            return Decimal('0')

    def find_column_index(self, headers: List[str], column_names: List[str]) -> Optional[int]:
        """Find the index of a column by trying multiple possible names"""
        for col_name in column_names:
            for i, header in enumerate(headers):
                if header and col_name.lower() in header.lower():
                    return i
        return None

    def process_excel_data(self, file_content: bytes) -> Dict[str, Any]:
        """Process Excel file from byte content"""
        logger.info("Processing uploaded Excel file")
        
        try:
            # Read Excel from bytes
            df = pd.read_excel(BytesIO(file_content), sheet_name=0, header=3, dtype=str)
            
            headers = df.columns.to_list()
            
            # Find column indices
            column_indices = {}
            for key, possible_names in self.column_mapping.items():
                idx = self.find_column_index(headers, possible_names)
                if idx is not None:
                    column_indices[key] = idx
                    logger.debug(f"Found {key} at column {idx}: {headers[idx]}")
            
            # Find actual columns (month columns)
            actual_columns = []
            for i, header in enumerate(headers):
                if isinstance(header, str) and any(
                    month in header.lower() for month in [
                        'january', 'february', 'march', 'april', 'may', 'june',
                        'july', 'august', 'september', 'october', 'november', 'december'
                    ]
                ):
                    year, month = self.parse_month_year(header)
                    actual_columns.append({
                        'index': i,
                        'header': header,
                        'year': year,
                        'month': month
                    })
            
            logger.info(f"Found {len(actual_columns)} actual columns")
            
            # Process projects
            projects = []
            for idx, row in df.iterrows():
                project_data = {
                    'project_number': str(row.iloc[column_indices.get('project_number', 2)]) if not pd.isna(row.iloc[column_indices.get('project_number', 2)]) else '',
                    'actuals': []
                }
                
                # Extract actual values
                for actual_col in actual_columns:
                    forecast_value = self.clean_forecast_value(row.iloc[actual_col['index']])
                    if forecast_value > 0:
                        project_data['actuals'].append({
                            'year': actual_col['year'],
                            'month': actual_col['month'],
                            'actual_amount': forecast_value
                        })
                
                projects.append(project_data)
            
            logger.info(f"Processed {len(projects)} projects")
            
            return {
                'projects': projects
            }
            
        except Exception as e:
            logger.error(f"Error processing Excel file: {e}")
            raise HTTPException(status_code=400, detail=f"Error processing Excel file: {str(e)}")

    def import_to_database(self, file_data: Dict[str, Any], db: Session) -> Dict[str, Any]:
        """Import processed data to database"""
        try:
            projects = file_data["projects"]
            updated_projects = 0
            updated_forecasts = 0
            
            for project in projects:
                project_number = project['project_number']
                
                if not project_number:
                    continue
                    
                actuals = project['actuals']
                
                # Find existing project
                existing_project = db.query(Project).filter_by(
                    project_number=project_number
                ).first()
                
                if existing_project:
                    updated_projects += 1
                    
                    for actual in actuals:
                        # Find existing forecast record
                        forecast = db.query(Forecast).filter(
                            Forecast.project_id == existing_project.id,
                            Forecast.year == actual['year'],
                            Forecast.month == actual['month'],
                            Forecast.forecast_type == "OB"
                        ).first()
                        
                        if forecast:
                            forecast.actuals = actual['actual_amount']
                            updated_forecasts += 1
            
            db.commit()
            
            return {
                "success": True,
                "updated_projects": updated_projects,
                "updated_forecasts": updated_forecasts,
                "message": f"Successfully updated {updated_projects} projects and {updated_forecasts} forecast records"
            }
            
        except Exception as e:
            db.rollback()
            logger.error(f"Unable to save to database: {e}")
            raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")

@router.post("/import-actuals")
async def import_actuals(
    file: UploadFile = File(...),
    created_by_user_id: str = "default-user-id",  # You might want to get this from authentication
    db: Session = Depends(get_db)
):
    """
    Import actual data from Excel file
    
    - **file**: Excel file (.xlsx) containing actual data
    - **created_by_user_id**: ID of the user performing the import
    """
    
    # Validate file type
    if not file.filename.endswith('.xlsx'):
        raise HTTPException(
            status_code=400, 
            detail="Only Excel files (.xlsx) are supported"
        )
    
    try:
        # Read file content
        file_content = await file.read()
        
        # Initialize processor
        processor = ActualExcelProcessor(created_by_user_id)
        
        # Process Excel data
        file_data = processor.process_excel_data(file_content)
        
        # Import to database
        result = processor.import_to_database(file_data, db)
        
        logger.info(f"Import completed successfully: {result}")
        
        return JSONResponse(
            status_code=200,
            content=result
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error during import: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Unexpected error: {str(e)}"
        )