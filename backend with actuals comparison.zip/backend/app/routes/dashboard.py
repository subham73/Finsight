from decimal import Decimal
from turtle import pd
from fastapi import APIRouter, Depends, HTTPException, Path, Query, status
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func, distinct
from core.auth import get_current_user
from core.database import get_db
from models import projects as project_model, forecasts as forecast_model, users as user_model
from models.exchange_rates import ExchangeRates
from datetime import datetime
from typing import Optional
import io
from uuid import UUID

from schemas.currency import CurrencyRatesUpdateRequest

router = APIRouter()

def get_user_projects(user, db: Session):
    """Reuse project filtering logic from projects.py"""
    if user.role == "PM":
        return db.query(project_model.Project).filter(project_model.Project.manager_id == user.id).all()
    elif user.role == "CH":
        return db.query(project_model.Project).filter(project_model.Project.cluster_id == user.cluster_id).all()
    else:  # SH
        return db.query(project_model.Project).all()

def get_financial_year_info(year=None):
    """Get financial year start, end and year based on current date or provided year"""
    now = datetime.now()
    if year:
        fy_year = year
        if now.month < 4:
            fy_start = datetime(year - 1, 4, 1)
            fy_end = datetime(year, 3, 31)
        else:
            fy_start = datetime(year, 4, 1)
            fy_end = datetime(year + 1, 3, 31)
    else:
        if now.month < 4:
            fy_start = datetime(now.year - 1, 4, 1)
            fy_end = datetime(now.year, 3, 31)
            fy_year = now.year - 1
        else:
            fy_start = datetime(now.year, 4, 1)
            fy_end = datetime(now.year + 1, 3, 31)
            fy_year = now.year
    
    return fy_start, fy_end, fy_year

def get_quarter_months(quarter):
    """Get months for a specific quarter in financial year (Apr-Mar)"""
    quarter_months = {
        "Q1": [4, 5, 6],     # Apr-Jun
        "Q2": [7, 8, 9],     # Jul-Sep
        "Q3": [10, 11, 12],  # Oct-Dec
        "Q4": [1, 2, 3]      # Jan-Mar
    }
    return quarter_months.get(quarter, [])

def get_forecasts_for_fy(project_ids, fy_year, db: Session, quarter=None):
    """Get forecasts for financial year (Apr-Mar) with optional quarter filter"""
    base_query = db.query(forecast_model.Forecast).filter(
        forecast_model.Forecast.project_id.in_(project_ids) if project_ids else False,
        or_(
            and_(
                forecast_model.Forecast.year == fy_year,
                forecast_model.Forecast.month >= 4
            ),
            and_(
                forecast_model.Forecast.year == fy_year + 1,
                forecast_model.Forecast.month <= 3
            )
        )
    )
    
    # Apply quarter filter if specified
    if quarter and quarter != "all":
        quarter_months = get_quarter_months(quarter)
        if quarter_months:
            base_query = base_query.filter(forecast_model.Forecast.month.in_(quarter_months))
    
    return base_query.all()

def convert_currency(amount, from_currency, to_currency, db: Session):
    """Convert amount from one currency to another using exchange rates"""
    if from_currency == to_currency:
        return float(amount)
    
    # Get exchange rates
    from_rate = db.query(ExchangeRates).filter(ExchangeRates.currency_code == from_currency).first()
    to_rate = db.query(ExchangeRates).filter(ExchangeRates.currency_code == to_currency).first()
    
    if not from_rate or not to_rate:
        # Fallback to original amount if rates not found
        return float(amount)
    
    # Convert to USD first, then to target currency
    usd_amount = float(amount) * float(from_rate.rate_to_usd)
    target_amount = usd_amount / float(to_rate.rate_to_usd)
    
    return target_amount

def convert_usd_to_currency(usd_amount, to_currency, db: Session):
    """Convert USD amount to target currency using exchange rates"""
    if to_currency == "USD":
        return float(usd_amount)
    
    # Get exchange rate for target currency
    to_rate = db.query(ExchangeRates).filter(ExchangeRates.currency_code == to_currency).first()
    
    if not to_rate:
        # Fallback to original amount if rate not found
        return float(usd_amount)
    
    # Convert from USD to target currency
    target_amount = float(usd_amount) / float(to_rate.rate_to_usd)
    
    return target_amount

def get_currency_symbol(currency_code):
    """Get currency symbol based on currency code"""
    symbols = {
        'USD': '$',
        'EUR': '€',
        'GBP': '£',
        'JPY': '¥',
        'INR': '₹',
        'CNY': '¥',
        'AUD': 'A$',
        'CAD': 'C$',
        'CHF': 'CHF',
        'SGD': 'S$'
    }
    return symbols.get(currency_code, currency_code)

@router.get("/summary")
def get_dashboard_summary(
    region: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    cluster: Optional[str] = Query(None),
    manager: Optional[str] = Query(None),
    vertical: Optional[str] = Query(None),
    currency: Optional[str] = Query(None),
    display_currency: Optional[str] = Query("INR"),
    year: Optional[int] = Query(None),
    quarter: Optional[str] = Query(None),
    user=Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # --- 1. Prepare basic info ---
    fy_start, fy_end, fy_year = get_financial_year_info(year)

    projects = get_user_projects(user, db)

    # Filter projects in memory
    if region and region != "all":
        projects = [p for p in projects if p.region == region]
    if status and status != "all":
        projects = [p for p in projects if p.status == status]
    if vertical and vertical != "all":
        projects = [p for p in projects if p.vertical == vertical]
    if cluster and cluster != "all":
        try:
            cluster_uuid = UUID(cluster)
            projects = [p for p in projects if p.cluster_id == cluster_uuid]
        except ValueError:
            projects = []
    if manager and manager != "all":
        try:
            manager_uuid = UUID(manager)
            projects = [p for p in projects if p.manager_id == manager_uuid]
        except ValueError:
            projects = []
    if currency and currency != "all":
        projects = [p for p in projects if p.currency == currency]

    project_ids = [p.id for p in projects]
    project_map = {p.id: p for p in projects}

    # --- 2. Get forecasts and exchange rate map ---
    forecasts = get_forecasts_for_fy(project_ids, fy_year, db, quarter)
    rates = db.query(ExchangeRates).all()
    rate_map = {r.currency_code: float(r.rate_to_usd) for r in rates}

    def convert_usd(usd_amount):
        if display_currency == "USD":
            return usd_amount
        rate = rate_map.get(display_currency)
        return usd_amount / rate if rate else usd_amount

    # --- 3. Setup ---
    display_months = get_quarter_months(quarter) if quarter and quarter != "all" else list(range(4, 13)) + list(range(1, 4))
    forecast_by_month = {month: 0 for month in display_months}
    actual_by_month = {month: 0 for month in display_months}

    # Pre-fetch cluster heads
    cluster_heads = db.query(user_model.User).filter(user_model.User.role == "CH").all()
    cluster_map = {ch.cluster_id: ch.name for ch in cluster_heads}

    # --- 4. Aggregate forecasts ---
    total_forecast = 0
    total_actual = 0
    region_forecast = {}
    vertical_forecast = {}

    for f in forecasts:
        if f.month not in display_months:
            continue

        usd_amount = float(f.forecast_usd) if f.forecast_usd else 0
        converted = convert_usd(usd_amount)
        forecast_by_month[f.month] += converted
        total_forecast += converted

        actual_amount = float(f.actuals) if f.actuals else 0
        actual_converted = convert_usd(actual_amount)
        actual_by_month[f.month] += actual_converted
        total_actual += actual_converted
        
        project = project_map.get(f.project_id)
        if not project:
            continue

        if project.region:
            region_forecast[project.region] = region_forecast.get(project.region, 0) + converted
        if project.vertical:
            vertical_forecast[project.vertical] = vertical_forecast.get(project.vertical, 0) + converted

    # --- 5. Group by properties ---
    projects_by_region = {}
    projects_by_status = {}
    projects_by_vertical = {}
    projects_by_cluster = {}
    projects_by_currency = {}

    for p in projects:
        if p.region:
            projects_by_region[p.region] = projects_by_region.get(p.region, 0) + 1
        if p.status:
            projects_by_status[p.status] = projects_by_status.get(p.status, 0) + 1
        if p.vertical:
            projects_by_vertical[p.vertical] = projects_by_vertical.get(p.vertical, 0) + 1
        if p.currency:
            projects_by_currency[p.currency] = projects_by_currency.get(p.currency, 0) + 1
        if p.cluster_id:
            cluster_name = f"Cluster - {cluster_map.get(p.cluster_id, 'Unknown')}"
            projects_by_cluster[cluster_name] = projects_by_cluster.get(cluster_name, 0) + 1

    # --- 6. Currency breakdown ---
    currency_breakdown = {}
    for curr, count in projects_by_currency.items():
        curr_total = sum(
            convert_usd(float(f.forecast_usd)) for f in forecasts
            if project_map.get(f.project_id) and project_map[f.project_id].currency == curr
        )
        currency_breakdown[curr] = {
            "project_count": count,
            "total_forecast": curr_total
        }

    # --- 7. Forecast by quarter ---
    if quarter and quarter != "all":
        forecast_by_quarter = {quarter: total_forecast}
    else:
        forecast_by_quarter = {
            "Q1": sum(forecast_by_month.get(m, 0) for m in [4, 5, 6]),
            "Q2": sum(forecast_by_month.get(m, 0) for m in [7, 8, 9]),
            "Q3": sum(forecast_by_month.get(m, 0) for m in [10, 11, 12]),
            "Q4": sum(forecast_by_month.get(m, 0) for m in [1, 2, 3])
        }

    # --- 8. Final response ---
    return {
        "role": user.role,
        "financial_year": f"{fy_year}-{fy_year + 1}",
        "display_currency": display_currency,
        "currency_symbol": get_currency_symbol(display_currency),
        "total_projects": len(projects),
        "total_forecast_amount": total_forecast,
        "total_actual_amount": total_actual,
        "forecast_by_month": forecast_by_month,
        "actual_by_month": actual_by_month,
        "forecast_by_quarter": forecast_by_quarter,
        "projects_by_region": projects_by_region,
        "projects_by_status": projects_by_status,
        "projects_by_vertical": projects_by_vertical,
        "projects_by_cluster": projects_by_cluster,
        "projects_by_currency": projects_by_currency,
        "currency_breakdown": currency_breakdown,
        "region_forecast": region_forecast,
        "vertical_forecast": vertical_forecast,
        "active_filters": {
            "region": region,
            "status": status,
            "cluster": cluster,
            "manager": manager,
            "currency": currency,
            "display_currency": display_currency,
            "year": fy_year,
            "quarter": quarter
        }
    }


@router.get("/trends")
def get_trend_analysis(
    display_currency: Optional[str] = Query("INR"),
    quarter: Optional[str] = Query(None),  # Add quarter filter to trends
    user=Depends(get_current_user), 
    db: Session = Depends(get_db)
):
    """Get trend analysis comparing current vs previous periods with currency conversion"""
    
    # Get current and previous FY info
    _, _, current_fy = get_financial_year_info()
    previous_fy = current_fy - 1
    
    # Get projects using existing logic
    projects = get_user_projects(user, db)
    project_ids = [p.id for p in projects]
    
    # Get forecasts for both years with quarter filter
    current_forecasts = get_forecasts_for_fy(project_ids, current_fy, db, quarter)
    previous_forecasts = get_forecasts_for_fy(project_ids, previous_fy, db, quarter)
    
    # Calculate totals using forecast_usd
    current_total = 0
    for f in current_forecasts:
        usd_amount = float(f.forecast_usd) if f.forecast_usd else 0
        converted_amount = convert_usd_to_currency(usd_amount, display_currency, db)
        current_total += converted_amount
    
    previous_total = 0
    for f in previous_forecasts:
        usd_amount = float(f.forecast_usd) if f.forecast_usd else 0
        converted_amount = convert_usd_to_currency(usd_amount, display_currency, db)
        previous_total += converted_amount
    
    growth_rate = ((current_total - previous_total) / previous_total * 100) if previous_total > 0 else 0
    
    period_suffix = f" ({quarter})" if quarter and quarter != "all" else ""
    
    return {
        "current_fy_total": current_total,
        "previous_fy_total": previous_total,
        "growth_rate": growth_rate,
        "current_fy": f"{current_fy}-{current_fy + 1}{period_suffix}",
        "previous_fy": f"{previous_fy}-{previous_fy + 1}{period_suffix}",
        "display_currency": display_currency,
        "currency_symbol": get_currency_symbol(display_currency),
        "quarter_filter": quarter
    }

@router.get("/exchange-rates")
def get_exchange_rates(db: Session = Depends(get_db)):
    """Get current exchange rates"""
    rates = db.query(ExchangeRates).all()
    return {
        "rates": [
            {
                "currency_code": rate.currency_code,
                "rate_to_usd": float(rate.rate_to_usd),
                "last_updated": rate.last_updated
            }
            for rate in rates
        ]
    }

@router.get("/currency-rates")
def get_currency_rates(
    user=Depends(get_current_user), 
    db: Session = Depends(get_db)
):
    """Get all currency exchange rates - Only accessible by SH role"""
    if user.role != "SH":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied. Only SH role users can access currency rates."
        )
    
    rates = db.query(ExchangeRates).order_by(ExchangeRates.currency_code).all()
    return [
        {
            "currency_code": rate.currency_code,
            "rate_to_usd": float(rate.rate_to_usd),
            "last_updated": rate.last_updated
        }
        for rate in rates
    ]

@router.put("/currency-rates")
def update_currency_rates(
    request: CurrencyRatesUpdateRequest,
    user=Depends(get_current_user), 
    db: Session = Depends(get_db)
):
    """Update currency exchange rates - Only accessible by SH role"""
    if user.role != "SH":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied. Only SH role users can modify currency rates."
        )
    
    try:
        # Update each currency rate
        for rate_update in request.rates:
            # Find existing rate
            existing_rate = db.query(ExchangeRates).filter(
                ExchangeRates.currency_code == rate_update.currency_code
            ).first()
            
            if existing_rate:
                # Update existing rate
                existing_rate.rate_to_usd = rate_update.rate_to_usd
                existing_rate.last_updated = func.now()
            else:
                # Create new rate if it doesn't exist
                new_rate = ExchangeRates(
                    currency_code=rate_update.currency_code,
                    rate_to_usd=rate_update.rate_to_usd
                )
                db.add(new_rate)
        
        db.commit()
        return {"message": "Currency rates updated successfully"}
        
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update currency rates: {str(e)}"
        )
    
# @router.post("/import-actuals")
# def import_actuals(db: Session = Depends(get_db)):
#     try:
#         file_path = Path(BASE_DIR) / "static" / "files" / "Actual_DATA.xlsx"
#         if not file_path.exists():
#             raise HTTPException(status_code=404, detail="Actuals file not found")

#         df = pd.read_excel(file_path, sheet_name=0, header=3)

#         month_map = {
#             'january': 1, 'february': 2, 'march': 3, 'april': 4, 'may': 5, 'june': 6,
#             'july': 7, 'august': 8, 'september': 9, 'october': 10, 'november': 11, 'december': 12
#         }

#         # Identify the actuals columns dynamically
#         actual_cols = []
#         for col in df.columns:
#             if isinstance(col, str) and "'" in col:
#                 parts = col.split("'")
#                 month = month_map.get(parts[0].strip().lower())
#                 year = int("20" + parts[1].strip())
#                 if month:
#                     actual_cols.append((col, year, month))

#         updated_count = 0

#         for _, row in df.iterrows():
#             project_number = str(row.get("IPMS ID")).strip()
#             if not project_number:
#                 continue

#             project = db.query(project_model.Project).filter(
#                 project_model.Project.project_number == project_number
#             ).first()

#             if not project:
#                 continue

#             for col_name, year, month in actual_cols:
#                 raw_value = row.get(col_name)
#                 try:
#                     value = Decimal(str(raw_value).strip()) if raw_value not in [None, '-', '', 'null', 'nan'] else Decimal('0')
#                 except:
#                     value = Decimal('0')

#                 if value > 0:
#                     forecast = db.query(forecast_model.Forecast).filter(
#                         forecast_model.Forecast.project_id == project.id,
#                         forecast_model.Forecast.year == year,
#                         forecast_model.Forecast.month == month,
#                         forecast_model.Forecast.forecast_type == "OB"
#                     ).first()

#                     if forecast:
#                         forecast.actuals = value
#                         updated_count += 1

#         db.commit()

#         return {"message": f"Successfully updated {updated_count} actual forecast values"}

#     except Exception as e:
#         db.rollback()
#         raise HTTPException(status_code=500, detail=f"Failed to import actuals: {str(e)}")
